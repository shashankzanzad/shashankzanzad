# todo-list-v1
This is a todolist project from Angela Yu's complete bootcamp. Using EJS, express and Node.js
->A To-do list Application 📋
->Skills: HTML, CSS, Bootstrap, JavaScript, Express, EJS.
