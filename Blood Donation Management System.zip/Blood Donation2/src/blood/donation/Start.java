/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blood.donation;

import java.sql.*; 
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * 
 */
public class Start extends javax.swing.JFrame {
Connection con=null;
Statement stmt=null;

    /**
     * Creates new form Start
     */
    public Start() {
        initComponents();
    try{
        Class.forName("java.sql.DriverManager");
        con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","root");
        stmt=(Statement)con.createStatement();
        String qd="create database if not exists Blooddonors;";
        String qu="use Blooddonors;";
            String qt="create table if not exists blddnrs(name varchar(50), bldgrp varchar(5), area varchar(30), phone varchar(20) primary key, age int(5), gender char(1));";
        stmt.executeUpdate(qd);stmt.executeUpdate(qu);stmt.executeUpdate(qt);
            String qsr="select *from blddnrs;";
            ResultSet rsr=stmt.executeQuery(qsr);
            if(rsr.next()){}
            else{
        String q="insert into blddnrs values";
        String q1=q+"('Ketan Patil','A+','Dahanu','9322364',46,'M');";
        String q2=q+"('Keerti Patil','A+','Dahanu','9372683263',46,'F');";
        String q3=q+"('Mandar Karandikar','A+','Dahanu','9325119783',50,'M');";
        String q4=q+"('Mohit Patil','A+','Chinchani','9371722549',25,'M');";
        String q5=q+"('Mohit Churi','A+','Chinchani','9260080916',25,'M');";
        String q6=q+"('Bhavesh Tamore','A+','Chinchani','9766489109',25,'M');";
        String q7=q+"('Prakash Adhiya','A+','Chinchani','9967870938',25,'M');";
        String q8=q+"('Ganesh Waghmare','B+','Dahanu','9028918188',25,'M');";
        String q9=q+"('Sanjay Pimpale','B+','Parnali','9049492453',25,'M');";
        String q10=q+"('Hemraj Gharat','B+','Chinchani','9762073765',25,'M');";
        String q11=q+"('Ketan Raut','B+','Chinchani','7798292996',25,'M');";
        String q12=q+"('Mayur Chaudhari','B+','Chinchani','9923788413',25,'M');";
        String q13=q+"('Atul Pingale','B+','Thane','9619436552',25,'M');";
        String q14=q+"('Vaibhav Patil','AB+','Chinchani','9923262750',25,'M');";
        String q15=q+"('Aashish Churi','AB+','Chinchani','7507989101',25,'M');";
        String q16=q+"('Jignesh Vajani','AB+','Dahanu','9272642101',25,'M');";
        String q17=q+"('Jagdish Pendkar','AB+','Aurangabad','9821255157',25,'M');";
        String q18=q+"('Anita Bhutada','AB+','Aurangabad','9158252439',25,'F');";
        String q19=q+"('Prathmesh Tendolkar','AB+','Chinchani','8149598399',25,'M');";
        String q20=q+"('Pralhad Chaudhari','O+','Chinchani','8007711957',25,'M');";
        String q21=q+"('Pradeep Patil','O+','Wadhvan','9823400454',25,'M');";
        String q22=q+"('Vishal Raut','O+','Chinchani','9860535753',25,'M');";
        String q23=q+"('Prashant Rana','O+','Chinchani','9860535751',25,'M');";
        String q24=q+"('Prashant Bhandari','O+','Chinchani','9637995598',25,'M');";
        String q25=q+"('Harshal Oza','O+','Chinchani','9765069147',25,'M');";
        String q26=q+"('Viraj Patil','A+','Chinchani','9823965860',25,'M');";
        String q27=q+"('Mayur Raut','A+','Chinchani','9823667966',25,'M');";
        String q28=q+"('Aashish Patil','A+','Chinchani','9730044047',25,'M');";
        String q29=q+"('Prasad Churi','A+','Chinchani','9372683252',25,'M');";
        String q30=q+"('Rohit Modale','A+','Chinchani','7875034300',25,'M');";
        String q31=q+"('Ganesh Champanerkar','A+','Chinchani','9823289131',25,'M');";
        String q32=q+"('Rajesh Churi','A+','Dahanu','9372683236',25,'M');";
        String q33=q+"('Devanand Shingde','A+','Chinchani','7507989100',25,'M');";
        String q34=q+"('Sunil Pawar','A+','Chinchani','8149359396',25,'M');";
        String q35=q+"('Umesh Chauhan','A+','Chinchani','9637818324',25,'M');";
        String q36=q+"('Nilesh Raut','A+','Chinchani','9226993067',25,'M');";
        String q37=q+"('Akshay Naik','A+','Chinchani','8080433222',25,'M');";
        String q38=q+"('Neel Churi','A+','Chinchani','7507327157',25,'M');";
        String q39=q+"('Nilesh Patil','A+','Chinchani','9422492550',25,'M');";
        String q40=q+"('Deepak Churi','A+','Chinchani','9765368565',25,'M');";
        String q41=q+"('Vaibhav Vaze','A+','Chinchani','9823206887',25,'M');";
        String q42=q+"('Prasad Raut','A+','Chinchani','9769492970',25,'M');";
        String q43=q+"('Bhushan Patil','A+','Vadade','9226498186',25,'M');";
        String q44=q+"('Kailas Naik','A+','Chinchani','9049666619',25,'M');";
        String q45=q+"('Piyush Desai','A+','Chinchani','8154883048',25,'M');";
        String q46=q+"('Avinash Patil','A+','Wadhvan','7226008901',25,'M');";
        String q47=q+"('Suvarna Rajput','A+','Aurangabad','9422212888',25,'F');";
        String q48=q+"('Parikshit Patil','A+','Chichani','9657588344',25,'M');";
        String q49=q+"('Dipesh Ambhire','A+','Chinchani','8087684838',25,'M');";
        String q50=q+"('Haresh Dhanu','A+','Chinchani','9029910922',25,'M');";
        String q51=q+"('Swapnil Saraskar','A+','Dahanu','',25, 'M');";
        String q52=q+"('Kalpak Patil','A+','Boisar','7378973181',45,'M');";
        String q53=q+"('Sudesh Thakur','A+','Borivalli','9769480302',25,'M');";
        String q54=q+"('Prajakta Patil','O+','Dahanu','9594367800',28,'F');";
        stmt.executeUpdate(q1);stmt.executeUpdate(q2);stmt.executeUpdate(q3);
        stmt.executeUpdate(q4);stmt.executeUpdate(q5);stmt.executeUpdate(q6);
        stmt.executeUpdate(q7);stmt.executeUpdate(q8);stmt.executeUpdate(q9);
        stmt.executeUpdate(q10);stmt.executeUpdate(q11);stmt.executeUpdate(q12);
        stmt.executeUpdate(q13);stmt.executeUpdate(q14);stmt.executeUpdate(q15);
        stmt.executeUpdate(q16);stmt.executeUpdate(q17);stmt.executeUpdate(q18);
        stmt.executeUpdate(q19);stmt.executeUpdate(q20);stmt.executeUpdate(q21);
        stmt.executeUpdate(q22);stmt.executeUpdate(q23);stmt.executeUpdate(q24);
        stmt.executeUpdate(q25);stmt.executeUpdate(q26);stmt.executeUpdate(q27);
        stmt.executeUpdate(q28);stmt.executeUpdate(q29);stmt.executeUpdate(q30);
        stmt.executeUpdate(q31);stmt.executeUpdate(q32);stmt.executeUpdate(q33);
        stmt.executeUpdate(q34);stmt.executeUpdate(q35);stmt.executeUpdate(q36);
        stmt.executeUpdate(q37);stmt.executeUpdate(q38);stmt.executeUpdate(q39);
        stmt.executeUpdate(q40);stmt.executeUpdate(q41);stmt.executeUpdate(q42);
        stmt.executeUpdate(q43);stmt.executeUpdate(q44);stmt.executeUpdate(q45);
        stmt.executeUpdate(q46);stmt.executeUpdate(q47);stmt.executeUpdate(q48);
        stmt.executeUpdate(q49);stmt.executeUpdate(q50);stmt.executeUpdate(q51);
        stmt.executeUpdate(q52);stmt.executeUpdate(q53);stmt.executeUpdate(q54);
            String qh="Create table if not exists hospitals(name varchar(30),area varchar(40),Phone int(20) primary key);";
            stmt.executeUpdate(qh);
            String qsrh="select *from hospitals;";
            ResultSet rsrh=stmt.executeQuery(qsrh);
            if(rsrh.next()){}
            else
        {String qh1="Insert into hospitals values('Phoenix Hospital','Dahanu',254868);";
        String qh2="Insert into hospitals values('Cottage Hospital','Dahanu',265465);";
        String qh3="Insert into hospitals values('Chinmaya Hospital','Boisar',549862);";
        String qh4="Insert into hospitals values('Vikas Hospital','Boisar',569832);";
        String qh5="Insert into hospitals values('Hinduja Hospital','Virar',565421);";
        String qh6="Insert into hospitals values('Palghar PHC ','Palghar',465983);";
        String qh7="Insert into hospitals values('KokilaBen Hospital','Mumbai',575757);";
        String qh8="Insert into hospitals values('Patil Hospital','Vasai',621232);";
        String qh9="Insert into hospitals values('Bagde Intensive Care Centre','Vasai',828282);";
        String qh10="Insert into hospitals values('Raj Health Care','Chinchani',958426);";
        stmt.executeUpdate(qh1);stmt.executeUpdate(qh2);stmt.executeUpdate(qh3);
        stmt.executeUpdate(qh4);stmt.executeUpdate(qh5);stmt.executeUpdate(qh6);
        stmt.executeUpdate(qh7);stmt.executeUpdate(qh8);stmt.executeUpdate(qh9);
        stmt.executeUpdate(qh10);}
            String qb="Create table if not exists bloodbanks(name varchar(30),area varchar(40),Phone int(20) primary key);";
            stmt.executeUpdate(qb);
            String qsrb="select *from bloodbanks;";
            ResultSet rsrb=stmt.executeQuery(qsrb);
            if(rsrb.next()){}
            else
        {String qb1="Insert into bloodbanks values('TAPS Blood Bank','Boisar',543516);";
        String qb2="Insert into bloodbanks values('Civil Hospital Blood Bank','Palghar',478553);";
        String qb3="Insert into bloodbanks values('Makhecha Blood Bank','Palghar',658766);";
        String qb4="Insert into bloodbanks values('Sankalp Blood Bank','Thane',768945);";
        String qb5="Insert into bloodbanks values('Jupiter Blood Bank','Vashi',867456);";
        String qb6="Insert into bloodbanks values('Vaidya Blood Bank','Virar',768576);";
        String qb7="Insert into bloodbanks values('Plasma Blood Bank','Dombivali',658467);";
        String qb8="Insert into bloodbanks values('MGM Blood Bank','Aurangabad',748565);";
        String qb9="Insert into bloodbanks values('Nair Hospital Blood Bank','Mumbai',758567);";
        String qb10="Insert into bloodbanks values('BSES MG Blood Bank','Andheri',576894);";
        stmt.executeUpdate(qb1);stmt.executeUpdate(qb2);stmt.executeUpdate(qb3);
        stmt.executeUpdate(qb4);stmt.executeUpdate(qb5);stmt.executeUpdate(qb6);
        stmt.executeUpdate(qb7);stmt.executeUpdate(qb8);stmt.executeUpdate(qb9);
        stmt.executeUpdate(qb10);}
            String qc="create table if not exists feedback(name varchar(50), phone varchar(15), feedback varchar(200), line int(3));";
            stmt.executeUpdate(qc);
            }
        }
        catch(Exception e){JOptionPane.showMessageDialog(this,e.getMessage());}
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        admin = new javax.swing.JButton();
        user = new javax.swing.JButton();
        exit = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Blood donors' family");
        setBackground(new java.awt.Color(255, 51, 102));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        admin.setBackground(new java.awt.Color(204, 204, 204));
        admin.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        admin.setForeground(new java.awt.Color(204, 0, 0));
        admin.setText("Admin");
        admin.setBorderPainted(false);
        admin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminActionPerformed(evt);
            }
        });
        getContentPane().add(admin, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 160, 130, 40));

        user.setBackground(new java.awt.Color(204, 204, 204));
        user.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        user.setForeground(new java.awt.Color(204, 0, 0));
        user.setText("User");
        user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userActionPerformed(evt);
            }
        });
        getContentPane().add(user, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 220, 110, 40));

        exit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        exit.setText("Exit");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });
        getContentPane().add(exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 310, -1, -1));

        jLabel1.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        jLabel1.setText(" To the Blood Donors' Family!");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, -1, -1));

        jLabel2.setFont(new java.awt.Font("Matura MT Script Capitals", 0, 24)); // NOI18N
        jLabel2.setText("Welcome");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void adminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        new Admin().setVisible(true);
    }//GEN-LAST:event_adminActionPerformed

    private void userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        new Welcome().setVisible(true);
    }//GEN-LAST:event_userActionPerformed

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
        // TODO add your handling code here:
        /*try{
            Class.forName("java.sql.DriverManager");
            con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","root");
            stmt=(Statement)con.createStatement();
            String qd="drop database Blooddonors;";
            stmt.executeUpdate(qd);}
        catch(Exception e){JOptionPane.showMessageDialog(this,e);}*/
        System.exit(0);
    }//GEN-LAST:event_exitActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Start().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton admin;
    private javax.swing.JButton exit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton user;
    // End of variables declaration//GEN-END:variables
}
